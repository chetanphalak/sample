sudo systemctl start apache2
python3 MasterInterface.py
sudo  service apache2 start
sudo service apache2.start
