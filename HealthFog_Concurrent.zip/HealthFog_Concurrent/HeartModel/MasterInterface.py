import os
import subprocess
import time
s=set()
while True:
    for File in os.listdir("."):
        if File.endswith(".csv") and File not in s:
            print("Got job")
            print(File)
            s.add(File)
            #os.system("python3 heartmodel.py "+File)
            subprocess.Popen("python3 heartmodel.py "+File,shell=True)
    else:
        time.sleep(0.1)
