import pandas as pd
from joblib import load
import sys
import os
from numpy import genfromtxt
import numpy as np
import warnings
warnings.simplefilter("ignore")

filename = sys.argv[1]
print("in hearmodel.py trying to remove",filename)
df = genfromtxt(filename, delimiter=',')

X = [df.astype(np.float64)]

clf = load('heartmodel.joblib')

result = clf.predict(X)[0].astype(int)
number=filename[4:]
number=number[:-4]
file = open('output'+number+'.txt','w')
os.remove(filename)
file.write(str(result))
file.close()
