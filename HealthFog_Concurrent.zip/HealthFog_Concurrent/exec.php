<?php
if(isset($_GET["cloud"])){
        $file = fopen("cloud.txt", "r");
        $ip = fgets($file);

        move_uploaded_file("data.csv", "data.csv");
        $tmp = file_get_contents("http://".$ip."/HealthFog/exec.php");

        echo $tmp;
}
else{
	echo("hello");
	$data=$_GET["data"];
	echo("data: ".$data."\n");
	while(true){
		if(file_exists("./HeartModel/output".$data.".txt"))
		break;
		else
			sleep(0.1);
	}
	$myfile = fopen("./HeartModel/output".$data.".txt", "r");
	if ($myfile==false){
		echo("no exi\st");}
	else{
        echo fread($myfile,filesize("./HeartModel/output".$data.".txt"));
        fclose($myfile);

	unlink("./HeartModel/output".$data.".txt");
	}
}
?>

