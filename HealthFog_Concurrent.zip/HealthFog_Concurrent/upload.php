
<?php
$data = $_GET['data'];
	$myfile = fopen("./HeartModel/counter.txt", "r");
	$filesize=filesize("./HeartModel/counter.txt");
	$contents=fread($myfile,$filesize);
	$contents=str_replace(array("\n","\r"),'',$contents);
	$file="./HeartModel/data".$contents.".csv";
	echo($contents);
	fclose($myfile);
   if (!(file_put_contents($file,$data) === FALSE)){
	   //echo "\nFile xfer completed.\n"; // file could be empty, though
	   $contents++;
	   unlink("./HeartModel/counter.txt");
	   $myfile=fopen("./HeartModel/counter.txt","w");
	   fwrite($myfile,$contents);
	   fclose($myfile);
   }
   else echo "File xfer failed.";
?>

