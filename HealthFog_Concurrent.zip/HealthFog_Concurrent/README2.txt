Changes made to existing healthfog framework
1) upload.php
	there is a file called counter.txt which stores a number, when a file is uploaded it is saved as data*.csv, where * represents a number.After each upload call counter gets increased.
	Upload also returns the number '*' which is saved and sends it back so that exec.php can execute the model on a paritcular model.
2) exec.php
	It recieves the number and then invokes an python scipt and passes data*.csv as arguements and waits until output*.txt is not created.
	it sends the result back and deletes output*.txt
3) heartmodel.py
	it deletes the file after it executes the model
4) MasterInterface.py
	it has a set so that after assigning a job, the same file is not sed again.